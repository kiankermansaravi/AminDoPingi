#ifndef DECORATOR_H
#define DECORATOR_H
#include"bodyobject.h"

class Decorator : public BodyObject{

public:
    Decorator();
};

#endif // DECORATOR_H
//mobin mirzaei
