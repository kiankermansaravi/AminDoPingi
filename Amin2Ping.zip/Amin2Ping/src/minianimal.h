#ifndef MINIANIMAL_H
#define MINIANIMAL_H

class MiniAnimal
{
public:
    MiniAnimal();
};

#endif // MINIANIMAL_H
