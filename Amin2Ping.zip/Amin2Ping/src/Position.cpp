#include "Position.h"

Position::Position()
    : x(0), y(0) {
}


Position::Position(int x, int y)
    : x(x), y(y) {
}

//kian kermansaravi
