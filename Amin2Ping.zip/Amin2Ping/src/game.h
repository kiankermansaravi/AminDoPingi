#ifndef GAME_H
#define GAME_H
#include<QGraphicsView>




class Game :  public QGraphicsView{


public:
    Game();
};

#endif // GAME_H
//kian kermansaravi
