#ifndef PLATFORM_H
#define PLATFORM_H


#include "bodyobject.h"

class Platform : public BodyObject {
public:
    Platform();

    void draw(QGraphicsScene &scene);
};

#endif // PLATFORM_H
//mobin mirzaei
