#include "game.h"
#include <QGraphicsScene>
#include"BackgroundDecorator.h"

Game::Game() {

    auto scene = new QGraphicsScene();
    scene->setSceneRect(position.x, position.y, w, h);
    scene->setBackgroundBrush(QBrush(QImage(":/im/b")));
    auto background = new BackgroundDecorator();

    scene->addItem(background);
    setScene(scene);
}
//kian kermansaravi





