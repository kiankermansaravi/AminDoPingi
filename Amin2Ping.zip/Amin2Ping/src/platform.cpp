#include "platform.h"
#include<QGraphicsScene>

void Platform :: draw(QGraphicsScene &scene){
    setHorizontalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);

    setPos(position.x,position.y);
    scene.setSceneRect(position.x, position.y, w, h);

    scene.setBackgroundBrush(QBrush(QImage(":/ima/p")));
    setScene(&scene);
}

//mobin mirzaei
