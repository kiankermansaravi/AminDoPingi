#ifndef BODYOBJECT_H
#define BODYOBJECT_H

#include <QGraphicsPixmapItem>
#include<QGraphicsView>
#include "Position.h"

class BodyObject : public QGraphicsPixmapItem {
public:
    int w;
    int h;
    Position position;

    BodyObject(int w, int h, Position position, QGraphicsPixmapItem* parent = nullptr);
    BodyObject();
    virtual ~BodyObject();


    virtual void draw(QGraphicsScene &scene) = 0;
};

#endif // BODYOBJECT_H

//kian kermansarvi
