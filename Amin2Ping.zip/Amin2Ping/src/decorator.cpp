#include "decorator.h"

Decorator::Decorator() : BodyObject(width(), height(), Position(0, 0) ){


}
//mobin mirzaei
