#include "backgrounddecorator.h"

BackgroundDecorator::BackgroundDecorator(QGraphicsItem *parent) : QGraphicsPixmapItem(parent){

    setHorizontalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);

    setPos(position.x,position.y);
    scene.setSceneRect(position.x, position.y, w, h);

    scene.setBackgroundBrush(QBrush(QImage(":/ima/p")));
    setScene(&scene);
}


//mobin mirzaei
