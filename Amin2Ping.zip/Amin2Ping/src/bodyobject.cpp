#include "bodyobject.h"

BodyObject::BodyObject(int width, int height, Position position, QGraphicsPixmapItem* parent)
    : QGraphicsPixmapItem(parent), w(width), h(height), position(position)

    setHorizontalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt ::ScrollBarAlwaysOff);
    auto scene = new QGraphicsScene();

    setPos(position.x,position.y);
    scene->setSceneRect(position.x, position.y, w, h);

    scene->setBackgroundBrush(QBrush(QImage()));
    setScene(scene);
    }


BodyObject :: BodyObject(){

}
//kian kermansaravi
