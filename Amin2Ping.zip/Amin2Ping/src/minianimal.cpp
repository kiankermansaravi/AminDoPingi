#include "minianimal.h"

MiniAnimal::MiniAnimal() {}
