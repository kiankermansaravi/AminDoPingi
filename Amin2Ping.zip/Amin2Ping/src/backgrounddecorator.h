#ifndef BACKGROUNDDECORATOR_H
#define BACKGROUNDDECORATOR_H
#include"BodyObject.h"

class BackgroundDecorator : public BodyObject{
public:
    BackgroundDecorator(QGraphicsItem *parent = nullptr);
};

#endif // BACKGROUNDDECORATOR_H
//mobin mirzaei
